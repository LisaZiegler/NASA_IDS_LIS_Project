%% Code to plot Envisat and Jason-2 Coastal Altimetry data: Sea Level Anomalies
% author: L. Ziegler (Nelson Mandela University, PE, South Africa) -  June 2017
%**********************************************************************************
close all
close all hidden
clear 
clc
%% Load data
file_sla = '/Users/lziegler/Google Drive/NewData_Thesis/gridded/AVISO_SLA/Durban.nc';

lat = double(ncread(file_sla,'latitude'));
lon = double(ncread(file_sla,'longitude'));
sla = double(ncread(file_sla,'sla'));
sla_time = double(ncread(file_sla,'time'))+datenum(1950,01,01);

minlat = min(lat);
maxlat = max(lat);
minlon = min(lon);
maxlon = max(lon);

latlim = [minlat maxlat];
lonlim = [minlon maxlon];

%%
sla_mtime = sla_time;
slasub = sla(:,:,indx_sla);
slasub_mtime = sla_mtime(indx_sla);
datestr(sla_mtime(365))
%%
struct = gshhs('gshhs_i.b',latlim,lonlim);
%%
for ifile = 2558:2922    
    data = sla(:,:,ifile);
    yyyymmdd = datestr(sla_mtime(ifile));
    
figure

clf
set(gcf,'color', 'white');
pcolor(lon,lat,data')
shading flat;
    set(gca,'DataAspectRatio',[1 cos(nanmean(lat)*pi/180) 1]);
    geoshow(struct,'FaceColor',[1 1 1]*0.82);
    hold on
    set(gca,'Layer','Top');
    grid on
    box on;
    hold on
caxis([-0.45 0.45]);
hbar = colorbar;
cmocean('balance','zero')

vv = (0:0.025:0.3);
    [c,h] = contour(lon,lat,data',vv,'k');
    clabel(c,h,'fontsize',13,'color','k')
    
    vv = [0,0];
    [c,h] = contour(lon,lat,lon,lat,data',vv,'k');
    set(h,'LineWidth',2)
    
vv = (-0.3:0.025:-0.025);
    [c,h] = contour(lon,lat,data',vv,'k');
    clabel(c,h,'fontsize',13,'color','k')
    set(h,'LineStyle','--','color','w','LineWidth',2)
set(gcf,'renderer','zbuffer')    

ylabel(hbar,'SLA (m)','Fontsize',12)
xlabel('Longitude','Fontsize',16)
ylabel('Latitude','Fontsize',16)
title([yyyymmdd],'Fontsize',16,'Fontweight','bold')

drawnow()
% pause(0.5)

 export_fig(sprintf('sla_000%d', ifile),'-a4','-q100', '-jpeg');
 
 close(figure)
 close hidden
end