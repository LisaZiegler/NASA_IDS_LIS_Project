/* <<< Release Notice for library >>> */

#include <projects.h>

char const pj_release[]="Rel. 4.5.0, 22 Oct 2006";

const char *pj_get_release()

{
    return pj_release;
}
